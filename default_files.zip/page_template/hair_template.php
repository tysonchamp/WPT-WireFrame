<?php
/*
 * Template Name: Hair Color
 */

get_header();
?>
        
    	<div class="container">
        <div class="filter_1">
        <!-- Filter Controls - Simple Mode -->
        <div class="row">
            <!-- A basic setup of simple mode filter controls, all you have to do is use data-filter="all"
            for an unfiltered gallery and then the values of your categories to filter between them -->
            <ul class="simplefilter">
                <?php
                    $orderby      = 'name';  
                    $show_count   = 0;      // 1 for yes, 0 for no
                    $pad_counts   = 0;      // 1 for yes, 0 for no
                    $hierarchical = 1;      // 1 for yes, 0 for no  
                    $title        = '';  
                    $empty        = 1;

                    $cat_args = array(
                        'number'     => $show_count,
                        'orderby'    => $orderby,
                        'order'      => 'ASC',
                        'hide_empty' => $empty
                    );
                    $product_categories = get_terms( 'color_cat', $cat_args );
                    // echo "<pre>";
                    // print_r($product_categories);
                ?>
                <li class="active" data-filter="all">All</li>
                <?php foreach ($product_categories as $cat_single) { ?>
                <li data-filter="<?php echo $cat_single->term_id; ?>"><?php echo $cat_single->name; ?></li
                <?php } ?>
            </ul>
        </div>

      
        <div class="row">
            <!-- This is the set up of a basic gallery, your items must have the categories they belong to in a data-category
            attribute, which starts from the value 1 and goes up from there -->
            <div class="filtr-container">
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="1, 5" data-sort="Busy streets">
                    <img class="img-responsive" src="img/blonde.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Blonde Hair</a></span>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="2, 5" data-sort="Luminous night">
                    <img class="img-responsive" src="img/natureblack.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Natural Black</a></span>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="3, 5" data-sort="City wonders">
                    <img class="img-responsive" src="img/brown.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Brown</a></span>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="4, 5" data-sort="In production">
                    <img class="img-responsive" src="img/omre.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Ombre</a></span>
                </div>
              	<div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="41, 5" data-sort="Industrial site">
                    <img class="img-responsive" src="img/dark_brown.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Dark Brown</a></span>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="6, 5" data-sort="Industrial site">
                    <img class="img-responsive" src="img/honey_blonde.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Honey Blonde</a></span>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="7, 5" data-sort="Industrial site">
                    <img class="img-responsive" src="img/light_blonde.jpg" alt="sample image">
                    <span class="item-desc">Light Blonde</span>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="8, 5" data-sort="Industrial site">
                    <img class="img-responsive" src="img/mix_gray.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Mix Gray</a></span>
                </div>
                <div class="col-xs-6 col-sm-4 col-md-3 filtr-item" data-category="9, 5" data-sort="Industrial site">
                    <img class="img-responsive" src="img/silver_hair.jpg" alt="sample image">
                    <span class="item-desc"><a href="#">Silver Gray</a></span>
                </div>
            </div>
        </div>
        </div>
    </div>
    	
<?php get_footer(); ?>