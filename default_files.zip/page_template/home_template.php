<?php
/*
 *Template Name: Home
 */

global $post;

// $images=$dynamic_featured_image->get_featured_images($id);

get_header();
?>
        <!-- MAIN CONTENT -->
        <section class="td_content">
            <div class="td_fullwidth">
                
                <!-- use jssor.slider.debug.js instead for debug -->
                <script>
                    jQuery(document).ready(function ($) {
                        
                        var jssor_1_SlideoTransitions = [
                          [{b:5500.0,d:3000.0,o:-1.0,r:240.0,e:{r:2.0}}],
                          [{b:-1.0,d:1.0,o:-1.0,c:{x:51.0,t:-51.0}},{b:0.0,d:1000.0,o:1.0,c:{x:-51.0,t:51.0},e:{o:7.0,c:{x:7.0,t:7.0}}}],
                          [{b:-1.0,d:1.0,o:-1.0,sX:9.0,sY:9.0},{b:1000.0,d:1000.0,o:1.0,sX:-9.0,sY:-9.0,e:{sX:2.0,sY:2.0}}],
                          [{b:-1.0,d:1.0,o:-1.0,r:-180.0,sX:9.0,sY:9.0},{b:2000.0,d:1000.0,o:1.0,r:180.0,sX:-9.0,sY:-9.0,e:{r:2.0,sX:2.0,sY:2.0}}],
                          [{b:-1.0,d:1.0,o:-1.0},{b:3000.0,d:2000.0,y:180.0,o:1.0,e:{y:16.0}}],
                          [{b:-1.0,d:1.0,o:-1.0,r:-150.0},{b:7500.0,d:1600.0,o:1.0,r:150.0,e:{r:3.0}}],
                          [{b:10000.0,d:2000.0,x:-379.0,e:{x:7.0}}],
                          [{b:10000.0,d:2000.0,x:-379.0,e:{x:7.0}}],
                          [{b:-1.0,d:1.0,o:-1.0,r:288.0,sX:9.0,sY:9.0},{b:9100.0,d:900.0,x:-1400.0,y:-660.0,o:1.0,r:-288.0,sX:-9.0,sY:-9.0,e:{r:6.0}},{b:10000.0,d:1600.0,x:-200.0,o:-1.0,e:{x:16.0}}]
                        ];
                        
                        var jssor_1_options = {
                          $AutoPlay: true,
                          $SlideDuration: 800,
                          $SlideEasing: $Jease$.$OutQuint,
                          $CaptionSliderOptions: {
                            $Class: $JssorCaptionSlideo$,
                            $Transitions: jssor_1_SlideoTransitions
                          },
                          $ArrowNavigatorOptions: {
                            $Class: $JssorArrowNavigator$
                          },
                          $BulletNavigatorOptions: {
                            $Class: $JssorBulletNavigator$
                          }
                        };
                        
                        var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);
                        
                        //responsive code begin
                        //you can remove responsive code if you don't want the slider scales while window resizing
                        function ScaleSlider() {
                            var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                            if (refSize) {
                                refSize = Math.min(refSize, 1920);
                                jssor_1_slider.$ScaleWidth(refSize);
                            }
                            else {
                                window.setTimeout(ScaleSlider, 30);
                            }
                        }
                        ScaleSlider();
                        $(window).bind("load", ScaleSlider);
                        $(window).bind("resize", ScaleSlider);
                        $(window).bind("orientationchange", ScaleSlider);
                        //responsive code end
                    });
                </script>

                <style>
                    
                    /* jssor slider bullet navigator skin 05 css */
                    /*
                    .jssorb05 div           (normal)
                    .jssorb05 div:hover     (normal mouseover)
                    .jssorb05 .av           (active)
                    .jssorb05 .av:hover     (active mouseover)
                    .jssorb05 .dn           (mousedown)
                    */
                    .jssorb05 {
                        position: absolute;
                    }
                    .jssorb05 div, .jssorb05 div:hover, .jssorb05 .av {
                        position: absolute;
                        /* size of bullet elment */
                        width: 16px;
                        height: 16px;
                        background: url('<?php get_template_directory_uri(); ?>/img/b05.png') no-repeat;
                        overflow: hidden;
                        cursor: pointer;
                    }
                    .jssorb05 div { background-position: -7px -7px; }
                    .jssorb05 div:hover, .jssorb05 .av:hover { background-position: -37px -7px; }
                    .jssorb05 .av { background-position: -67px -7px; }
                    .jssorb05 .dn, .jssorb05 .dn:hover { background-position: -97px -7px; }

                    /* jssor slider arrow navigator skin 22 css */
                    /*
                    .jssora22l                  (normal)
                    .jssora22r                  (normal)
                    .jssora22l:hover            (normal mouseover)
                    .jssora22r:hover            (normal mouseover)
                    .jssora22l.jssora22ldn      (mousedown)
                    .jssora22r.jssora22rdn      (mousedown)
                    */
                    .jssora22l, .jssora22r {
                        display: block;
                        position: absolute;
                        /* size of arrow element */
                        width: 40px;
                        height: 58px;
                        cursor: pointer;
                        background: url('<?php get_template_directory_uri(); ?>/img/a22.png') center center no-repeat;
                        overflow: hidden;
                    }
                    .jssora22l { background-position: -10px -31px; }
                    .jssora22r { background-position: -70px -31px; }
                    .jssora22l:hover { background-position: -130px -31px; }
                    .jssora22r:hover { background-position: -190px -31px; }
                    .jssora22l.jssora22ldn { background-position: -250px -31px; }
                    .jssora22r.jssora22rdn { background-position: -310px -31px; }
                </style>
                <div id="jssor_1" style="position: relative; margin: 0 auto; top: 0px; left: 0px; width: 1300px; height: 600px; overflow: hidden; visibility: hidden;">
                    <!-- Loading Screen -->
                    <div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
                        <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
                        <div style="position:absolute;display:block;background:url('<?php get_template_directory_uri(); ?>/img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
                    </div>
                    <div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 1300px; height: 600px; overflow: hidden;">
                        <?php

                        	// check if the repeater field has rows of data
							if( have_rows('slider') ):

							 	// loop through the rows of data
							    while ( have_rows('slider') ) : the_row();
				                $img = get_sub_field('slider_image');

							        // display a sub field value
						?>
									<div data-p="225.00" style="display: none;">
			                            <img data-u="image" src="<?php echo $img['url']; ?>" />
			                        </div>
						<?php

							    endwhile;

							endif;

						?>
                    </div>
                    <!-- Bullet Navigator -->
                    <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
                        <!-- bullet navigator item prototype -->
                        <div data-u="prototype" style="width:16px;height:16px;"></div>
                    </div>
                    <!-- Arrow Navigator -->
                    <span data-u="arrowleft" class="jssora22l" style="top:0px;left:12px;width:40px;height:58px;" data-autocenter="2"></span>
                    <span data-u="arrowright" class="jssora22r" style="top:0px;right:12px;width:40px;height:58px;" data-autocenter="2"></span>  
                </div>  
                                
            </div>
            
            <!-- SECTION -->
            <section class="td_section" id="td_section_b">
                <div class="container">
                    
                    <div class="space100"></div>
                    
                    <!-- TITLE -->
                    <div class="td_section_title"><h3><span>Our Available<span> Hair Color</span></span></h3></div>
                    <!-- /TITLE -->
                    
                    <!-- FROM SERVICE -->
                    <div class="serviceIntro">
                        
                        <ul class="etabs">
                            <?php
                                $orderby      = 'name';  
                                $show_count   = 0;      // 1 for yes, 0 for no
                                $pad_counts   = 0;      // 1 for yes, 0 for no
                                $hierarchical = 1;      // 1 for yes, 0 for no  
                                $title        = '';  
                                $empty        = 1;

                                $cat_args = array(
                                    'number'     => $show_count,
                                    'orderby'    => $orderby,
                                    'order'      => 'ASC',
                                    'hide_empty' => $empty
                                );
                                $product_categories = get_terms( 'color_cat', $cat_args );
                                // echo "<pre>";
                                // print_r($product_categories);
                            ?>
                            <?php foreach ($product_categories as $cat_single) { ?>
                                <li><a href="#<?php echo $cat_single->slug; ?>"><?php echo $cat_single->name; ?></a></li>
                            <?php } ?>
                            <!--<li><a href="#tabs2">Brunette Hair</a></li>
                            <li><a href="#tabs3">Black Hair</a></li>
                            <li><a href="#tabs4">Streak Colored Hair</a></li>-->
                           
                        </ul>
                        <div class="tabcontent">
                            <?php
                                /**
                                 * The WordPress Query class.
                                 * @link http://codex.wordpress.org/Function_Reference/WP_Query
                                 *
                                 */
                                $args = array(
                                    //Choose ^ 'any' or from below, since 'any' cannot be in an array
                                    'post_type' =>  'hair_color',
                                    'post_status' => 'publish',
                                    //Order & Orderby Parameters
                                    'order'               => 'DESC',
                                    //Pagination Parameters
                                    'nopaging'               => true,
                                );
                                
                                $query = new WP_Query( $args );

                                if( $query->have_posts() ):
                                    while( $query->have_posts() ) : $query->the_post();
                                        $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_id() ), 'single-post-thumbnail' );
                                        $categories_list = get_the_terms( get_the_id() , 'color_cat' );
                                        foreach ($categories_list as $single_term) {
                                            $cat_id[] = $single_term->slug;
                                        }
                                        $cats = join(' ', $cat_id);
                                        $cat_id = "";
                            ?>
                                        <div id="<?php echo $cats; ?>">
                                            <div class="img_holder">
                                                <img src="<?php echo $image[0]; ?>" alt="" />
                                                <div class="content_holder">
                                                    <div class="td_holder_in">
                                                        <div>
                                                            <h4><?php the_title( ); ?></h4>
                                                            <p><?php the_excerpt(); ?><div class="button_type"><a href="<?php the_permalink(); ?>">See More..</button></a></div></p>                     
                                                        </div>
                                                    </div>
                                                    <a href="<?php the_permalink(); ?>" class="read_more"><i class="xcon-right-open-big"></i></a>
                                                </div>
                                            </div>
                                        </div>
                            <?php
                                    endwhile;
                                endif;
                            ?>
                            
                        </div>
                    </div>
                    <!-- /FROM SERVICE -->
                    
                </div>
                
               
                
                <!-- PARALLAX -->
                
                <!-- /PARALLAX -->
            
            </section>
            <!-- /SECTION -->
            
        </section>
        <!-- /MAIN CONTENT -->
        
<?php get_footer(); ?>